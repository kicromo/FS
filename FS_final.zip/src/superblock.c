#include <stdio.h>
#include <string.h>
#include "superblock.h"
#include "file.h"

void init_superblock(Superblock* sb) {
    sb->magic_number = 0xF00DBABE;
    sb->num_blocks = NUM_BLOCKS;
    sb->block_size = BLOCK_SIZE;
    sb->num_inodes = NUM_INODES;
    sb->root_inode_index = ROOT_DIR_INODE;

    memset(sb->free_block_bitmap, 0, sizeof(sb->free_block_bitmap));
    memset(sb->free_inode_bitmap, 0, sizeof(sb->free_inode_bitmap));

    // Calcular bloques reservados
    //SUPERBLOCK_BLOCKS ya incluido en el bitmap de bloques
    int inode_table_blocks = (NUM_INODES * sizeof(Inode) + BLOCK_SIZE - 1) / BLOCK_SIZE;
    int reserved_blocks = SUPERBLOCK_BLOCKS + inode_table_blocks;
    
    // Reservar bloques del FS: suponiendo:
    // bloque 0 = superbloque, 1 = bitmap bloques, 2 = bitmap inodos, 3-130 = inodos (128 bloques)
    for (int i = 0; i <= reserved_blocks; i++) {
        sb->free_block_bitmap[i / 32] |= (1 << (i % 32));
    }
    
    // Reservar inodo raíz
    sb->free_inode_bitmap[ROOT_DIR_INODE / 32] |= (1 << (ROOT_DIR_INODE % 32));
}



int write_superblock(FILE* fp, Superblock* sb) {
    fseek(fp, 0, SEEK_SET);
    return fwrite(sb, sizeof(Superblock), 1, fp) == 1 ? 0 : -1;
}

int read_superblock(FILE* fp, Superblock* sb) {
    fseek(fp, 0, SEEK_SET);
    return fread(sb, sizeof(Superblock), 1, fp) == 1 ? 0 : -1;
}

//******************* SUPER BLOCK *****************/

int allocate_block(Superblock* sb){
    for (int i = 1; i < sb->num_blocks; i++) {
        if (is_block_free(sb, i)) {
            sb->free_block_bitmap[i / 32] |= (1 << (i % 32));
            return i;
        }
    }
    return -1;
}

void free_block(Superblock* sb, int block_num){
    sb->free_block_bitmap[block_num / 32] &= ~(1 << (block_num % 32));
}
int is_block_free(Superblock* sb, int block_num){
    return !(sb->free_block_bitmap[block_num / 32] & (1 << (block_num % 32)));
}




//******************* INODOS ********************/



int allocate_inode(Superblock* sb){
    for (int i = 1; i < sb->num_inodes; i++) {
        if (is_inode_free(sb, i)) {
            sb->free_inode_bitmap[i / 32] |= (1 << (i % 32));
            return i;
        }
    }
    return -1; // No hay inodos libres
}

void free_inode(Superblock* sb, int inode_num){
    sb->free_inode_bitmap[inode_num / 32] &= ~(1 << (inode_num % 32));
}
int is_inode_free(Superblock* sb, int inode_num){
    return !(sb->free_inode_bitmap[inode_num / 32] & (1 << (inode_num % 32)));
}