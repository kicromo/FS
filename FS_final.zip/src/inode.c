#include <stdio.h>
#include <string.h>
#include "inode.h"
#include "superblock.h"
#include "fs.h"

int write_inode(FILE* fp, int index, const Inode* inode){
    // 3 * BLOCK_SIZE = 3 bloques reservados para el superbloque y los bitmaps
    // index * sizeof(Inode) = posición del inodo en el bloque de inodos
    // SEEK_SET = posición desde el inicio del archivo
    // INODE_TABLE_OFFSET = 3 * BLOCK_SIZE
    //printf("write_inode %d: usado=%d, dir=%d, size=%d\n", index, inode->used, inode->is_directory, inode->size);
    long offset = INODE_TABLE_OFFSET + index * sizeof(Inode);
    if (fseek(fp, offset, SEEK_SET) != 0) {
        perror("fseek");
        return -1;
    }
    if (fwrite(inode, sizeof(Inode), 1, fp) != 1) {
        perror("fwrite");
        return -1;
    }
    //printf("write_inode %d → offset = %ld, used = %d, dir = %d, size = %d\n", index, offset, inode->used, inode->is_directory, inode->size);
    fflush(fp); // Asegurarse de que los datos se escriban en el disco
    return 0;
}
int read_inode(FILE* fp, int index, Inode* inode){
    long offset = INODE_TABLE_OFFSET + index * sizeof(Inode);
    if (fseek(fp, offset, SEEK_SET) != 0) {
        perror("fseek");
        return -1;
    }
    if (fread(inode, sizeof(Inode), 1, fp) != 1) {
        perror("fread");
        return -1;
    }
    fflush(fp); // Asegurarse de que los datos se lean del disco
    return 0;
}

void clear_inode(Inode* inode) {
    memset(inode, 0, sizeof(Inode));  // Primero limpia toda la estructura
    memset(inode->block_pointers, -1, sizeof(inode->block_pointers));
    inode->indirect1 = -1;
    inode->indirect2 = -1;
    // Nota: ¡Esto sobrescribe used/is_directory/size a 0!
}
int allocate_data_block_for_inode(Inode* inode, int logical_block_idx, int* physical_block_num, FILE* fp, Superblock* sb, int inode_index){
    if (logical_block_idx < 0 || logical_block_idx >= DIRECT_BLOCKS) {
        return -1; // Error: índice de bloque lógico fuera de rango
    }

    // Si el bloque lógico ya está asignado, devolverlo
    if (inode->block_pointers[logical_block_idx] != -1) {
        *physical_block_num = inode->block_pointers[logical_block_idx];
        return 0;
    }

    // Asignar un nuevo bloque físico
    *physical_block_num = allocate_block(sb);
    if (*physical_block_num == -1) {
        return -1; // Error: no hay bloques libres
    }

    inode->block_pointers[logical_block_idx] = *physical_block_num;
    write_inode(fp, inode_index, inode); // Actualizar el inodo en el disco

    return 0;
}
int get_data_block_from_inode(const Inode* inode, int logical_block_idx, int* physical_block_num, FILE* fp){
    if (logical_block_idx < 0 || logical_block_idx >= DIRECT_BLOCKS) {
        return -1; // Error: índice de bloque lógico fuera de rango
    }

    // Si el bloque lógico ya está asignado, devolverlo
    if (inode->block_pointers[logical_block_idx] != -1) {
        *physical_block_num = inode->block_pointers[logical_block_idx];
        return 0;
    }

    return -1; // Error: bloque lógico no asignado
}
