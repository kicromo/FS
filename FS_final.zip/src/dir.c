#include <stdio.h>
#include <string.h>
#include <time.h>
#include "types.h"
#include "fs.h"         // Donde están definidas ROOT_DIR_INODE, BLOCK_SIZE, etc.
#include "superblock.h" // Para read_superblock, write_superblock
#include "inode.h"      // Para read_inode, write_inode, allocate_inode, free_inode
#include "block.h"      // Para allocate_block, write_block, free_block
#include "dir.h"        // Para funciones de directorios
#include "file.h"       // Para funciones de archivos


int create_dir(const char* path) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        perror("read_superblock");
        fclose(fp);
        return -1;
    }

    // 1. Usar resolve_path para encontrar directorio padre e hijo
    Inode parent_inode;
    int parent_index;
    char name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, path, &parent_inode, &parent_index, name) != 0) {
        printf("Error: no se pudo resolver ruta padre.\n");
        fclose(fp);
        return -1;
    }
    printf("primer puntero directo del padre: %d\n", parent_inode.block_pointers[0]);   

    // Vamos a imprimir resolve path para ver qué devuelve
    printf("imprimiendo resolve_path.....\n");
    printf("parent_inode root index: %d, name hijo: %s\n", parent_index, name);
    printf("\n");

    // 2. Verificar si ya existe la entrada
    DirEntry tmp;
    if (find_entry_in_dir(fp, &parent_inode, name, &tmp) == 0) {
        printf("Ya existe una entrada con el nombre: %s\n", name);
        fclose(fp);
        return -1;
    }

    // 3. Crear inodo del nuevo directorio
    Inode new_dir_inode = {0};
    new_dir_inode.used = 1;
    new_dir_inode.is_directory = 1;
    new_dir_inode.size = 0;
    for (int i = 0; i < DIRECT_BLOCKS; i++) new_dir_inode.block_pointers[i] = -1;
    new_dir_inode.indirect1 = -1;
    new_dir_inode.indirect2 = -1;
    long now = time(NULL);
    new_dir_inode.atime = now;
    new_dir_inode.mtime = now;
    new_dir_inode.ctime = now;
    new_dir_inode.mode = 0755; 

    int dir_block = allocate_block(&sb);
    if (dir_block == -1) {
        printf("No hay bloques de datos disponibles para el directorio.\n");
        fclose(fp);
        return -1;
    }
    new_dir_inode.block_pointers[0] = dir_block;
    printf("[DEBUG] Reservando bloque de datos para nuevo dir '%s': %d\n", name, dir_block);

    // 4. Reservar inodo
    int new_inode_index = allocate_inode(&sb);
    if (new_inode_index == -1) {
        printf("No hay inodos libres.\n");
        fclose(fp);
        return -1;
    }

    if (write_inode(fp, new_inode_index, &new_dir_inode) != 0) {
        perror("write_inode (new dir)");
        fclose(fp);
        return -1;
    }

    // 5. Añadir entrada en el directorio padre
    if (add_entry_to_dir(fp, &parent_inode, parent_index, name, new_inode_index) != 0) {
        perror("add_entry_to_dir");
        fclose(fp);
        return -1;
    }

    write_superblock(fp, &sb);
    fclose(fp);

    printf("Directorio creado: %s\n", path);
    return 0;
}

int delete_dir(const char* path){
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    Inode parent_inode;
    int parent_index;
    char name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, path, &parent_inode, &parent_index, name) != 0) {
        printf("Directorio padre no encontrado.\n");
        fclose(fp);
        return -1;
    }

    DirEntry entry;
    if (find_entry_in_dir(fp, &parent_inode, name, &entry) != 0) {
        printf("Directorio no encontrado: %s\n", path);
        fclose(fp);
        return -1;
    }

    Inode dir_inode;
    if (read_inode(fp, entry.inode_index, &dir_inode) != 0 || !dir_inode.is_directory) {
        printf("No es un directorio válido.\n");
        fclose(fp);
        return -1;
    }

    if (dir_inode.size > 0) {
        printf("El directorio no está vacío.\n");
        fclose(fp);
        return -1;
    }

    for (int i = 0; i < DIRECT_BLOCKS; i++) {
        if (dir_inode.block_pointers[i] != -1)
            free_block(&sb, dir_inode.block_pointers[i]);
    }

    free_inode(&sb, entry.inode_index);
    remove_entry_from_dir(fp, &parent_inode, parent_index, name);

    write_superblock(fp, &sb);
    fclose(fp);
    printf("Directorio eliminado: %s\n", path);
    return 0;
}

int rename_dir(const char* old_path, const char* new_name){
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) return -1;

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    Inode parent_inode;
    int parent_index;
    char old_name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, old_path, &parent_inode, &parent_index, old_name) != 0) {
        printf("Ruta no encontrada: %s\n", old_path);
        fclose(fp);
        return -1;
    }

    DirEntry tmp;
    if (find_entry_in_dir(fp, &parent_inode, new_name, &tmp) == 0) {
        printf("Ya existe una entrada con el nuevo nombre.\n");
        fclose(fp);
        return -1;
    }

    int entries = parent_inode.size / sizeof(DirEntry);
    for (int i = 0; i < entries; i++) {
        long offset = parent_inode.block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
        fseek(fp, offset, SEEK_SET);
        fread(&tmp, sizeof(DirEntry), 1, fp);
        if (strcmp(tmp.name, old_name) == 0) {
            strncpy(tmp.name, new_name, FILENAME_LEN);
            fseek(fp, offset, SEEK_SET);
            fwrite(&tmp, sizeof(DirEntry), 1, fp);
            write_superblock(fp, &sb);
            fclose(fp);
            printf("Directorio renombrado: %s → %s\n", old_name, new_name);
            return 0;
        }
    }

    fclose(fp);
    return -1;
}

int list_dir(const char* path) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) {
        perror("Error al abrir el sistema de archivos");
        return -1;
    }

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    // Acceso directo al root
    if (strcmp(path, "/") == 0) {
        printf("[DEBUG] Accediendo al directorio raíz directamente\n");

        Inode root_inode;
        if (read_inode(fp, ROOT_DIR_INODE, &root_inode) != 0) {
            fclose(fp);
            return -1;
        }

        printf("Contenido de /:\n");
        DirEntry entry;
        int num_entries = root_inode.size / sizeof(DirEntry);
        for (int i = 0; i < num_entries; i++) {
            long offset = root_inode.block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
            fseek(fp, offset, SEEK_SET);
            fread(&entry, sizeof(DirEntry), 1, fp);
            printf("  · %s (inodo: %d)\n", entry.name, entry.inode_index);
        }

        root_inode.atime = time(NULL);
        write_inode(fp, ROOT_DIR_INODE, &root_inode);
        fclose(fp);
        return 0;
    }

    // Resolver el path completo al directorio
    Inode parent_inode;
    int parent_index;
    char name[FILENAME_LEN];

    printf("[DEBUG] Resolviendo ruta: %s\n", path);
    if (resolve_path_to_parent(fp, path, &parent_inode, &parent_index, name) != 0) {
        printf("Ruta no encontrada: %s\n", path);
        fclose(fp);
        return -1;
    }

    DirEntry entry;
    if (find_entry_in_dir(fp, &parent_inode, name, &entry) != 0) {
        printf("No existe el directorio: %s\n", path);
        fclose(fp);
        return -1;
    }

    Inode target_inode;
    if (read_inode(fp, entry.inode_index, &target_inode) != 0 || !target_inode.is_directory) {
        printf("No es un directorio válido: %s\n", path);
        fclose(fp);
        return -1;
    }

    // Listar entradas del directorio
    printf("Contenido de %s:\n", path);
    int num_entries = target_inode.size / sizeof(DirEntry);
    DirEntry entry_in_dir;
    for (int i = 0; i < num_entries; i++) {
        long offset = target_inode.block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
        fseek(fp, offset, SEEK_SET);
        fread(&entry_in_dir, sizeof(DirEntry), 1, fp);
        printf("  · %s (inodo: %d)\n", entry_in_dir.name, entry_in_dir.inode_index);
    }

    target_inode.atime = time(NULL);
    write_inode(fp, entry.inode_index, &target_inode);
    fclose(fp);
    return 0;
}

// name -> nombre del archivo
// dir_inode -> inodo del directorio
// out -> puntero a la entrada de directorio encontrada
int find_entry_in_dir(FILE* fp, Inode* dir_inode, const char* name, DirEntry* out){
    if (dir_inode->size == 0) return -1; // Vacío

    int entries_per_block = BLOCK_SIZE / sizeof(DirEntry);
    int total_entries = dir_inode->size / sizeof(DirEntry);
    int entries_read = 0;

    // 1. Buscar en bloques directos
    for (int i = 0; i < DIRECT_BLOCKS && entries_read < total_entries; i++) {
        if (dir_inode->block_pointers[i] != -1) {
            long base_offset = dir_inode->block_pointers[i] * BLOCK_SIZE;

            for (int j = 0; j < entries_per_block && entries_read < total_entries; j++, entries_read++) {
                DirEntry entry;
                fseek(fp, base_offset + j * sizeof(DirEntry), SEEK_SET);
                fread(&entry, sizeof(DirEntry), 1, fp);
                if (strcmp(entry.name, name) == 0) {
                    if (out) *out = entry;
                    return 0;
                }
            }
        }
    }

    // 2. Buscar en bloque indirecto simple
    if (dir_inode->indirect1 != -1 && entries_read < total_entries) {
        int indirect_buffer[BLOCK_SIZE / sizeof(int)];
        read_indirect_block(fp, dir_inode->indirect1, indirect_buffer);

        for (int i = 0; i < BLOCK_SIZE / sizeof(int) && entries_read < total_entries; i++) {
            if (indirect_buffer[i] != -1) {
                long base_offset = indirect_buffer[i] * BLOCK_SIZE;

                for (int j = 0; j < entries_per_block && entries_read < total_entries; j++, entries_read++) {
                    DirEntry entry;
                    fseek(fp, base_offset + j * sizeof(DirEntry), SEEK_SET);
                    fread(&entry, sizeof(DirEntry), 1, fp);
                    if (strcmp(entry.name, name) == 0) {
                        if (out) *out = entry;
                        return 0;
                    }
                }
            }
        }
    }

    return -1; // No encontrado
}

int add_entry_to_dir(FILE* fp, Inode* dir_inode, int dir_index, const char* name, int inode_index) {
    if (dir_inode->size >= MAX_FILES_PER_DIR * sizeof(DirEntry)) {
        return -1; // El directorio está lleno
    }

    
    DirEntry entry = {0};
    strncpy(entry.name, name, FILENAME_LEN);
    entry.inode_index = inode_index;

    
    Superblock sb;
    read_superblock(fp, &sb);

    int entries_per_block = BLOCK_SIZE / sizeof(DirEntry);
    int total_entries = dir_inode->size / sizeof(DirEntry);

    int final_block_num = -1;
    int offset_in_block = -1;

    // Buscar espacio en bloques directos
    for (int i = 0; i < DIRECT_BLOCKS; i++) {
        if (dir_inode->block_pointers[i] != -1) {
            int used = total_entries % entries_per_block;
            if (used < entries_per_block) {
                final_block_num = dir_inode->block_pointers[i];
                offset_in_block = used;
                break;
            }
        } else {
            // Asignar nuevo bloque aquí
            int new_block = allocate_block(&sb);
            if (new_block == -1) return -1;
            dir_inode->block_pointers[i] = new_block;
            write_superblock(fp, &sb);
            final_block_num = new_block;
            offset_in_block = 0;
            break;
        }
    }

    // 🔄 2. Si no hay espacio en bloques directos, usar indirecto simple
    if (final_block_num == -1) {
        if (dir_inode->indirect1 == -1) {
            dir_inode->indirect1 = allocate_block(&sb);
            if (dir_inode->indirect1 == -1) return -1;

            // Inicializar el bloque indirecto a -1
            int empty[BLOCK_SIZE / sizeof(int)];
            for (int i = 0; i < BLOCK_SIZE / sizeof(int); i++) empty[i] = -1;
            write_indirect_block(fp, dir_inode->indirect1, empty);
            write_superblock(fp, &sb);
        }

        int indirect_buffer[BLOCK_SIZE / sizeof(int)];
        read_indirect_block(fp, dir_inode->indirect1, indirect_buffer);

        for (int i = 0; i < BLOCK_SIZE / sizeof(int); i++) {
            if (indirect_buffer[i] != -1) {
                int used = total_entries % entries_per_block;
                if (used < entries_per_block) {
                    final_block_num = indirect_buffer[i];
                    offset_in_block = used;
                    break;
                }
            } else {
                // Asignar nuevo bloque de datos
                int new_block = allocate_block(&sb);
                if (new_block == -1) return -1;
                indirect_buffer[i] = new_block;
                final_block_num = new_block;
                offset_in_block = 0;
                write_indirect_block(fp, dir_inode->indirect1, indirect_buffer);
                write_superblock(fp, &sb);
                break;
            }
        }
    }

    if (final_block_num == -1) return -1;

    printf("[DEBUG] Escribiendo DirEntry '%s' (inode %d) en bloque %d (de inodo %d), offset %ld\n",
        entry.name, entry.inode_index, final_block_num, dir_index,
        final_block_num * BLOCK_SIZE + offset_in_block * sizeof(DirEntry));
 
    
    // ✍️ Escribir la entrada
    long base_offset = final_block_num * BLOCK_SIZE + offset_in_block * sizeof(DirEntry);
    fseek(fp, base_offset, SEEK_SET);
    fwrite(&entry, sizeof(DirEntry), 1, fp);

    // 📏 Actualizar metadatos
    dir_inode->size += sizeof(DirEntry);
    long now = time(NULL);
    dir_inode->mtime = now;
    dir_inode->ctime = now;
    write_inode(fp, dir_index, dir_inode);
    return 0;
}

int remove_entry_from_dir(FILE* fp, Inode* dir_inode, int dir_index, const char* name) {
    DirEntry entry;
    if (find_entry_in_dir(fp, dir_inode, name, &entry) != 0) {
        return -1; // Entrada no encontrada
    }

    int num_entries = dir_inode->size / sizeof(DirEntry);
    for (int i = 0; i < num_entries; i++) {
        long offset = dir_inode->block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
        fseek(fp, offset, SEEK_SET);
        fread(&entry, sizeof(DirEntry), 1, fp);

        if (strcmp(entry.name, name) == 0) {
            // Sobrescribir con la última entrada
            DirEntry last_entry;
            long last_offset = dir_inode->block_pointers[0] * BLOCK_SIZE + (num_entries - 1) * sizeof(DirEntry);
            fseek(fp, last_offset, SEEK_SET);
            fread(&last_entry, sizeof(DirEntry), 1, fp);

            fseek(fp, offset, SEEK_SET);
            fwrite(&last_entry, sizeof(DirEntry), 1, fp);
            break;
        }
    }

    // Actualizar tamaño, tiempos y escribir inodo
    dir_inode->size -= sizeof(DirEntry);
    long now = time(NULL);
    dir_inode->mtime = now;
    dir_inode->ctime = now;
    write_inode(fp, dir_index, dir_inode);
    return 0;
}


int read_indirect_block(FILE* fp, int block_num, int* buffer){
    long offset = block_num * BLOCK_SIZE;
    fseek(fp, offset, SEEK_SET);
    return fread(buffer, sizeof(int), BLOCK_SIZE / sizeof(int), fp);
}

int write_indirect_block(FILE* fp, int block_num, int* buffer){
    long offset = block_num * BLOCK_SIZE;
    fseek(fp, offset, SEEK_SET);
    return fwrite(buffer, sizeof(int), BLOCK_SIZE / sizeof(int), fp) == BLOCK_SIZE / sizeof(int) ? 0 : -1;
}
