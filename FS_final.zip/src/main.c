#include <stdio.h>
#include <string.h>
#include "file.h"
#include "dir.h"

int main() {
    // Formatear FS
    printf("==> Formateando sistema...\n");
    mkfs();
    printf("==> Sistema formateado\n");
    return 0;
}