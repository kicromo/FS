#include <stdio.h>
#include <string.h>
#include "block.h"
#include "fs.h"

void clear_block(FILE* fp, int block_num){
    DataBlock zero = {0};
    fseek(fp, block_num * BLOCK_SIZE, SEEK_SET);
    fwrite(&zero, sizeof(DataBlock), 1, fp);
}
void write_block(FILE* fp, int block_num, const char* data, size_t len){
    if (len > BLOCK_SIZE) {
        len = BLOCK_SIZE; // Limitar la longitud a BLOCK_SIZE
    }
    fseek(fp, block_num * BLOCK_SIZE, SEEK_SET);
    fwrite(data, sizeof(char), len, fp);
}
void read_block(FILE* fp, int block_num, char* buffer){
    fseek(fp, block_num * BLOCK_SIZE, SEEK_SET);
    fread(buffer, sizeof(char), BLOCK_SIZE, fp);
}
