#include <stdio.h>
#include <string.h>
#include <libgen.h> // para strtok
#include <time.h>
#include "file.h"
#include "superblock.h"
#include "inode.h"
#include "block.h"
#include "dir.h"


void mkfs() {
    FILE* fp = fopen(FS_IMAGE, "w+b");
    if (!fp) {
        perror("fopen");
        return;
    }

    // 1. Inicializar superbloque
    Superblock sb;
    init_superblock(&sb);
    printf("[DEBUG] Bitmap de inodos tras init: %08X\n", sb.free_inode_bitmap[0]);

    // 2.- Vamos a reservar un bloque de datos para el directorio raíz
    int root_block = allocate_block(&sb);
    if (root_block == -1) {
        printf("Error: no se pudo asignar bloque para el root.\n");
        fclose(fp);
        return;
    }
    // 3. Crear y escribir inodo raíz
    Inode root = {0};
    root.used = 1;
    root.is_directory = 1;
    root.size = 0;
    for (int i = 0; i < DIRECT_BLOCKS; i++) root.block_pointers[i] = -1;
    root.indirect1 = -1;
    root.indirect2 = -1;
    root.block_pointers[0] = root_block;
    root.mode = 0755;

    if (write_inode(fp, 0, &root) != 0) {
        perror("write_inode root");
        fclose(fp);
        return;
    }

    // 4. Escribir el resto de los inodos vacíos
    Inode empty = {0};
    for (int i = 1; i < NUM_INODES; i++) {
        write_inode(fp, i, &empty);
    }

    // 5. Rellenar los bloques de datos con ceros
    DataBlock zero = {0};
    int inode_table_blocks = (NUM_INODES * sizeof(Inode) + BLOCK_SIZE - 1) / BLOCK_SIZE;
    int reserved_blocks = SUPERBLOCK_BLOCKS + inode_table_blocks;
    for (int i = 0; i < NUM_BLOCKS - reserved_blocks; i++) {
        fwrite(&zero, sizeof(DataBlock), 1, fp);
    }

    if (write_superblock(fp, &sb) != 0) {
        perror("write_superblock");
        fclose(fp);
        return;
    }

    fclose(fp);
    printf("Filesystem creado correctamente.\n");
    printf("-------------------------------\n");
}

int create_file(const char* path, const char* content) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        perror("read_superblock");
        fclose(fp);
        return -1;
    }

    Inode parent_inode;
    int parent_index;
    char name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, path, &parent_inode, &parent_index, name) != 0) {
        printf("Directorio padre no encontrado para: %s\n", path);
        fclose(fp);
        return -1;
    }

    DirEntry entry;
    if (find_entry_in_dir(fp, &parent_inode, name, &entry) == 0) {
        printf("El archivo ya existe.\n");
        fclose(fp);
        return -1;
    }

    int num_blocks = (strlen(content) + BLOCK_SIZE - 1) / BLOCK_SIZE;
    int max_indirect1_entries = BLOCK_SIZE / sizeof(int);
    if (num_blocks > DIRECT_BLOCKS + max_indirect1_entries) {
        printf("Archivo demasiado grande (requiere indirecto doble).\n");
        fclose(fp);
        return -1;
    }

    int new_inode_index = allocate_inode(&sb);
    if (new_inode_index == -1) {
        printf("No hay inodos libres.\n");
        fclose(fp);
        return -1;
    }

    Inode new_inode = {0};
    new_inode.used = 1;
    new_inode.is_directory = 0;
    new_inode.size = strlen(content);
    for (int i = 0; i < DIRECT_BLOCKS; i++) new_inode.block_pointers[i] = -1;
    new_inode.indirect1 = -1;
    new_inode.indirect2 = -1;
    long now = time(NULL);
    new_inode.atime = now;
    new_inode.mtime = now;
    new_inode.ctime = now;
    new_inode.mode = 0644; 

    int indirect_block_data[max_indirect1_entries];
    int indirect_block_used = 0;

    for (int i = 0; i < num_blocks; i++) {
        int block_num = allocate_block(&sb);
        if (block_num == -1) {
            printf("No hay bloques libres.\n");
            fclose(fp);
            return -1;
        }

        if (i < DIRECT_BLOCKS) {
            new_inode.block_pointers[i] = block_num;
        } else {
            if (new_inode.indirect1 == -1) {
                int indirect_block = allocate_block(&sb);
                if (indirect_block == -1) {
                    printf("No hay bloques libres para indirecto.\n");
                    fclose(fp);
                    return -1;
                }
                new_inode.indirect1 = indirect_block;
                memset(indirect_block_data, -1, sizeof(indirect_block_data));
            }
            indirect_block_data[i - DIRECT_BLOCKS] = block_num;
            indirect_block_used = 1;
        }

        char buffer[BLOCK_SIZE] = {0};
        strncpy(buffer, content + i * BLOCK_SIZE, BLOCK_SIZE);
        write_block(fp, block_num, buffer, BLOCK_SIZE);
    }

    if (indirect_block_used) {
        write_block(fp, new_inode.indirect1, (char*)indirect_block_data, BLOCK_SIZE);
    }

    if (write_inode(fp, new_inode_index, &new_inode) == -1) {
        perror("write_inode (new file)");
        fclose(fp);
        return -1;
    }

    if (add_entry_to_dir(fp, &parent_inode, parent_index, name, new_inode_index) != 0) {
        perror("add_entry_to_dir (create_file)");
        fclose(fp);
        return -1;
    }

    write_inode(fp, parent_index, &parent_inode);
    write_superblock(fp, &sb);
    fclose(fp);
    return 0;
}

int read_file(const char* path, char* buffer, size_t size) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) return -1;

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    printf("[DEBUG] Leyendo archivo: %s\n", path);
    // Usamos resolve_path para obtener directamente el inodo del archivo
    Inode file_inode;
    int file_inode_index;
    
    //char dummy[FILENAME_LEN];
    if (resolve_full_path(fp, path, &file_inode, &file_inode_index) != 0){
        fclose(fp);
        return -1;
    }
    printf("OK: Inodo del archivo encontrado: %d\n", file_inode_index);
    if (file_inode.is_directory) {
        fclose(fp);
        return -1;  // No se puede leer un directorio como archivo
    }

    memset(buffer, 0, size);
    int bytes_to_read = file_inode.size;
    int total_read = 0;

    // Leer bloques directos
    for (int i = 0; i < DIRECT_BLOCKS && total_read < bytes_to_read; i++) {
        if (file_inode.block_pointers[i] == -1) break;

        char block[BLOCK_SIZE] = {0};
        read_block(fp, file_inode.block_pointers[i], block);

        int copy_size = (bytes_to_read - total_read < BLOCK_SIZE) ? (bytes_to_read - total_read) : BLOCK_SIZE;
        memcpy(buffer + total_read, block, copy_size);
        total_read += copy_size;
    }

    // Leer bloques indirectos simples
    if (file_inode.indirect1 != -1 && total_read < bytes_to_read) {
        int pointers[BLOCK_SIZE / sizeof(int)];
        read_block(fp, file_inode.indirect1, (char*)pointers);

        for (int j = 0; j < BLOCK_SIZE / sizeof(int) && total_read < bytes_to_read; j++) {
            if (pointers[j] == -1) break;

            char block[BLOCK_SIZE] = {0};
            read_block(fp, pointers[j], block);

            int copy_size = (bytes_to_read - total_read < BLOCK_SIZE) ? (bytes_to_read - total_read) : BLOCK_SIZE;
            memcpy(buffer + total_read, block, copy_size);
            total_read += copy_size;
        }
    }
    // Actualizar tiempos de acceso
    file_inode.atime = time(NULL);
    write_inode(fp, file_inode_index, &file_inode);
    fclose(fp);
    return 0;
}

int write_file(const char* path, const char* content) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) return -1;

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    Inode parent_inode;
    int parent_index;
    char name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, path, &parent_inode, &parent_index, name) != 0) {
        printf("Ruta no válida: %s\n", path);
        fclose(fp);
        return -1;
    }

    DirEntry entry;
    if (find_entry_in_dir(fp, &parent_inode, name, &entry) != 0) {
        printf("Archivo '%s' no encontrado dentro del directorio %d\n", name, parent_index);
        fclose(fp);
        return -1;
    }

    Inode file_inode;
    if (read_inode(fp, entry.inode_index, &file_inode) != 0 || file_inode.is_directory) {
        printf("Inodo inválido o es un directorio: %d\n", entry.inode_index);
        fclose(fp);
        return -1;
    }

    printf("Sobrescribiendo inodo %d (%s)\n", entry.inode_index, path);

    // Liberar bloques anteriores
    for (int i = 0; i < DIRECT_BLOCKS; i++) {
        if (file_inode.block_pointers[i] != -1) {
            free_block(&sb, file_inode.block_pointers[i]);
            file_inode.block_pointers[i] = -1;
        }
    }

    if (file_inode.indirect1 != -1) {
        int pointers[BLOCK_SIZE / sizeof(int)];
        read_block(fp, file_inode.indirect1, (char*)pointers);
        for (int i = 0; i < BLOCK_SIZE / sizeof(int); i++) {
            if (pointers[i] != -1) free_block(&sb, pointers[i]);
        }
        free_block(&sb, file_inode.indirect1);
        file_inode.indirect1 = -1;
    }

    // Escribir contenido nuevo
    int total_written = 0;
    int bytes_to_write = strlen(content);
    int num_blocks = (bytes_to_write + BLOCK_SIZE - 1) / BLOCK_SIZE;
    int max_indirect1_entries = BLOCK_SIZE / sizeof(int);
    int indirect_block_data[max_indirect1_entries];
    int indirect_block_used = 0;
    for (int i = 0; i < max_indirect1_entries; i++) indirect_block_data[i] = -1;

    for (int i = 0; i < num_blocks; i++) {
        int block = allocate_block(&sb);
        if (block == -1) break;
        if (i < DIRECT_BLOCKS) {
            file_inode.block_pointers[i] = block;
        } else {
            if (file_inode.indirect1 == -1) {
                int indirect_block = allocate_block(&sb);
                if (indirect_block == -1) break;
                file_inode.indirect1 = indirect_block;
                for (int j = 0; j < max_indirect1_entries; j++) indirect_block_data[j] = -1;
            } else {
                // Si ya existe, leer los punteros actuales
                read_block(fp, file_inode.indirect1, (char*)indirect_block_data);
            }
            indirect_block_data[i - DIRECT_BLOCKS] = block;
            indirect_block_used = 1;
        }
        char buffer[BLOCK_SIZE] = {0};
        strncpy(buffer, content + i * BLOCK_SIZE, BLOCK_SIZE);
        write_block(fp, block, buffer, BLOCK_SIZE);
        total_written += (bytes_to_write - total_written < BLOCK_SIZE) ? (bytes_to_write - total_written) : BLOCK_SIZE;
    }
    if (indirect_block_used) {
        write_block(fp, file_inode.indirect1, (char*)indirect_block_data, BLOCK_SIZE);
    }
    // Limpiar punteros no usados
    for (int i = num_blocks; i < DIRECT_BLOCKS; i++) file_inode.block_pointers[i] = -1;
    // Actualizar tamaño y tiempos
    file_inode.size = bytes_to_write;
    long now = time(NULL);
    file_inode.mtime = now;
    file_inode.ctime = now;
    write_inode(fp, entry.inode_index, &file_inode);
    write_superblock(fp, &sb);
    fclose(fp);
    return 0;
}

int delete_file(const char* path) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    Inode parent_inode;
    int parent_index;
    char name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, path, &parent_inode, &parent_index, name) != 0) {
        printf("Ruta no válida: %s\n", path);
        fclose(fp);
        return -1;
    }

    DirEntry entry;
    if (find_entry_in_dir(fp, &parent_inode, name, &entry) != 0) {
        printf("Archivo no encontrado: %s\n", name);
        fclose(fp);
        return -1;
    }

    Inode file_inode;
    if (read_inode(fp, entry.inode_index, &file_inode) != 0 || file_inode.is_directory) {
        printf("No es un archivo válido.\n");
        fclose(fp);
        return -1;
    }

    // Liberar bloques de datos
    for (int i = 0; i < DIRECT_BLOCKS; i++) {
        if (file_inode.block_pointers[i] != -1)
            free_block(&sb, file_inode.block_pointers[i]);
    }

    if (file_inode.indirect1 != -1) {
        int pointers[BLOCK_SIZE / sizeof(int)];
        read_block(fp, file_inode.indirect1, (char*)pointers);

        for (int i = 0; i < BLOCK_SIZE / sizeof(int); i++) {
            if (pointers[i] != -1)
                free_block(&sb, pointers[i]);
        }

        free_block(&sb, file_inode.indirect1);
    }

    // Liberar inodo
    free_inode(&sb, entry.inode_index);

    // Eliminar entrada del directorio padre
    remove_entry_from_dir(fp, &parent_inode, parent_index, name);

    write_superblock(fp, &sb);
    fclose(fp);
    printf("Archivo eliminado: %s\n", path);
    return 0;
}

int rename_file(const char* old_path, const char* new_path) {
    FILE* fp = fopen(FS_IMAGE, "r+b");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    Superblock sb;
    if (read_superblock(fp, &sb) != 0) {
        fclose(fp);
        return -1;
    }

    // === Obtener padre e info del archivo original ===
    printf("[DEBUG] Renombrando archivo: %s a %s\n", old_path, new_path);
    Inode src_parent_inode;
    int src_parent_index;
    char src_name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, old_path, &src_parent_inode, &src_parent_index, src_name) != 0) {
        printf("Archivo original no encontrado: %s\n", old_path);
        fclose(fp);
        return -1;
    }

    DirEntry entry;
    if (find_entry_in_dir(fp, &src_parent_inode, src_name, &entry) != 0) {
        printf("No se encontró la entrada: %s\n", src_name);
        fclose(fp);
        return -1;
    }

    // === Obtener padre e info del nuevo path ===
    Inode dst_parent_inode;
    int dst_parent_index;
    char dst_name[FILENAME_LEN];
    if (resolve_path_to_parent(fp, new_path, &dst_parent_inode, &dst_parent_index, dst_name) != 0) {
        printf("Directorio destino no encontrado: %s\n", new_path);
        fclose(fp);
        return -1;
    }

    // === Verificar si ya existe una entrada con el nuevo nombre ===
    DirEntry check_entry;
    if (find_entry_in_dir(fp, &dst_parent_inode, dst_name, &check_entry) == 0) {
        printf("Ya existe un archivo llamado '%s' en el destino. Eliminando...\n", dst_name);
        if (remove_entry_from_file_dir(fp, &dst_parent_inode, dst_parent_index, dst_name) != 0) {
            printf("Error al eliminar el archivo existente '%s'.\n", dst_name);
            fclose(fp);
            return -1;
        }
    }
    

    // === Si es el mismo directorio: renombrar directamente ===
    if (src_parent_index == dst_parent_index) {
        int num_entries = src_parent_inode.size / sizeof(DirEntry);
        for (int i = 0; i < num_entries; i++) {
            long offset = src_parent_inode.block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
            fseek(fp, offset, SEEK_SET);
            fread(&entry, sizeof(DirEntry), 1, fp);

            if (strcmp(entry.name, src_name) == 0) {
                strncpy(entry.name, dst_name, FILENAME_LEN);
                fseek(fp, offset, SEEK_SET);
                fwrite(&entry, sizeof(DirEntry), 1, fp);
                // Actualizar tiempo cambio
                Inode file_inode;
                if (read_inode(fp, entry.inode_index, &file_inode) == 0) {
                    file_inode.ctime = time(NULL);
                    write_inode(fp, entry.inode_index, &file_inode);
                }
                src_parent_inode.ctime = time(NULL);
                write_inode(fp, src_parent_index, &src_parent_inode);
                printf("[DEBUG] Renombrado directamente en offset %ld\n", offset);
                fclose(fp);
                return 0;
            }
        }

        printf("No se encontró la entrada para renombrar directamente.\n");
        fclose(fp);
        return -1;
    }

    // === Si cambia de directorio: eliminar + añadir ===
    if (remove_entry_from_file_dir(fp, &src_parent_inode, src_parent_index, src_name) != 0) {
        printf("No se pudo eliminar la entrada original: %s\n", src_name);
        fclose(fp);
        return -1;
    }

    if (add_entry_to_dir(fp, &dst_parent_inode, dst_parent_index, dst_name, entry.inode_index) != 0) {
        printf("Error al añadir '%s' en el nuevo directorio.\n", dst_name);
        fclose(fp);
        return -1;
    }
    // Actualizacion de tiempos
    Inode file_inode;
    if (read_inode(fp, entry.inode_index, &file_inode) == 0) {
        file_inode.ctime = time(NULL);
        write_inode(fp, entry.inode_index, &file_inode);
    }
    src_parent_inode.ctime = time(NULL);
    write_inode(fp, src_parent_index, &src_parent_inode);
    dst_parent_inode.ctime = time(NULL);
    write_inode(fp, dst_parent_index, &dst_parent_inode);

    write_superblock(fp, &sb);
    fclose(fp);
    printf("Archivo renombrado/movido: %s -> %s\n", old_path, new_path);
    return 0;
}

int resolve_path_to_parent(FILE* fp, const char* path, Inode* parent_inode, int* parent_index, char* name) {
    if (!fp || !path || !parent_inode || !parent_index || !name) {
        return -1;
    }

    if (strcmp(path, "/") == 0) {
        return -1; // No hay padre del root
    }

    char temp[strlen(path) + 1];
    strcpy(temp, path);

    int current_inode_index = ROOT_DIR_INODE;
    Inode current_inode;
    if (read_inode(fp, current_inode_index, &current_inode) != 0) {
        return -1;
    }

    char* token = strtok(temp, "/");
    char* next_token = NULL;

    while (token != NULL) {
        next_token = strtok(NULL, "/");

        if (next_token == NULL) {
            // Este es el último token: detenernos aquí y devolver el padre
            *parent_inode = current_inode;
            *parent_index = current_inode_index;
            strcpy(name, token);
            return 0;
        }

        if (!current_inode.is_directory) return -1;

        DirEntry entry;
        if (find_entry_in_dir(fp, &current_inode, token, &entry) != 0) {
            return -1;
        }

        current_inode_index = entry.inode_index;
        if (read_inode(fp, current_inode_index, &current_inode) != 0) {
            return -1;
        }

        token = next_token;
    }

    return -1; // no debería llegar aquí
}

int resolve_full_path(FILE* fp, const char* path, Inode* inode_out, int* inode_index_out) {
    if (!fp || !path || !inode_out || !inode_index_out) return -1;

    Inode parent;
    int parent_index;
    char name[FILENAME_LEN];

    // Obtenemos el padre + nombre final
    if (resolve_path_to_parent(fp, path, &parent, &parent_index, name) != 0)
        return -1;

    // Buscamos la entrada con ese nombre en el directorio padre
    DirEntry entry;
    if (find_entry_in_dir(fp, &parent, name, &entry) != 0)
        return -1;

    if (read_inode(fp, entry.inode_index, inode_out) != 0)
        return -1;

    *inode_index_out = entry.inode_index;
    return 0;
}

int remove_entry_from_file_dir(FILE* fp, Inode* dir_inode, int dir_index, const char* name) {
    DirEntry entry;
    int num_entries = dir_inode->size / sizeof(DirEntry);

    for (int i = 0; i < num_entries; i++) {
        long offset = dir_inode->block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
        fseek(fp, offset, SEEK_SET);
        fread(&entry, sizeof(DirEntry), 1, fp);

        if (strcmp(entry.name, name) == 0) {

            if (i != num_entries - 1) {
                // Leer última entrada
                DirEntry last_entry;
                long last_offset = dir_inode->block_pointers[0] * BLOCK_SIZE + (num_entries - 1) * sizeof(DirEntry);
                fseek(fp, last_offset, SEEK_SET);
                fread(&last_entry, sizeof(DirEntry), 1, fp);

                // Sobrescribir entrada actual con la última
                fseek(fp, offset, SEEK_SET);
                fwrite(&last_entry, sizeof(DirEntry), 1, fp);
            }

            // Reducir tamaño del directorio
            dir_inode->size -= sizeof(DirEntry);
            write_inode(fp, dir_index, dir_inode);
            return 0;
        }
    }

    return -1; // No se encontró la entrada
}


// int resolve_path(FILE* fp, const char* path, Inode* parent_inode, int* parent_index, char* name) {
//     if (!fp || !path || !parent_inode || !parent_index || !name) {
//         return -1;
//     }

//     // Caso especial: ruta raíz
//     if (strcmp(path, "/") == 0) {
//         *parent_index = ROOT_DIR_INODE;
//         read_inode(fp, ROOT_DIR_INODE, parent_inode);
//         strcpy(name, "/");
//         return 0;
//     }

//     char temp[strlen(path) + 1];
//     strcpy(temp, path);

//     int current_inode_index = ROOT_DIR_INODE;
//     Inode current_inode;
//     if (read_inode(fp, current_inode_index, &current_inode) != 0) {
//         printf("[resolve_path] Error leyendo inodo raíz\n");
//         return -1;
//     }

//     char* token = strtok(temp, "/");
//     char* next_token = NULL;
//     char last_valid_name[FILENAME_LEN] = {0};

//     while (token != NULL) {
//         // Guardar el siguiente token antes de avanzar
//         next_token = strtok(NULL, "/");

//         // Verificar si el componente actual es un directorio
//         if (!current_inode.is_directory) {
//             printf("[resolve_path] '%s' no es un directorio\n", last_valid_name);
//             return -1;
//         }

//         // Buscar la entrada en el directorio actual
//         DirEntry entry;
//         if (find_entry_in_dir(fp, &current_inode, token, &entry) != 0) {
//             if (next_token == NULL) {
//                 // Este es el último componente y no existe - es el que queremos crear
//                 *parent_inode = current_inode;
//                 *parent_index = current_inode_index;
//                 strcpy(name, token);
//                 return 0;
//             } else {
//                 // Componente intermedio no encontrado
//                 printf("[resolve_path] Directorio no encontrado: '%s' en '%s'\n", 
//                        token, last_valid_name[0] ? last_valid_name : "/");
//                 return -1;
//             }
//         }

//         // Avanzar al siguiente inodo
//         current_inode_index = entry.inode_index;
//         if (read_inode(fp, current_inode_index, &current_inode) != 0) {
//             printf("[resolve_path] Error leyendo inodo %d\n", current_inode_index);
//             return -1;
//         }

//         strcpy(last_valid_name, token);
//         token = next_token;
//     }

//     // Si llegamos aquí, la ruta existe completamente
//     // En este caso, deberíamos devolver el último directorio y el nombre vacío
//     // Pero según tu caso de uso, esto no debería ocurrir para create_dir
//     // Si llegamos aquí, la ruta existe completamente
//     // Si llegamos aquí, la ruta existe completamente
//     if (name != NULL) {
//         // Querían el último componente como 'nombre'
//         strcpy(name, last_valid_name);
//     }
//     *parent_inode = current_inode;
//     *parent_index = current_inode_index;
//     return 0;


//     return -1;
// }

//****************** */
