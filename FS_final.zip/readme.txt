Sistema de Ficheros FUSE - GrupoK
---------------------------------

Autores: Ilie Perez y Diego Machaca


Instrucciones de compilación y uso:

1. Compilar el sistema de ficheros y generar la imagen:                             make 

2. Montar el sistema de ficheros en el directorio 'punto_montaje':                  make install

3. Desmontar el sistema de ficheros:                                                make uninstall

4. Quitar todos los archivos creados:                                               make cleanall


