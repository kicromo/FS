#ifndef FS_H
#define FS_H

#define FS_SIZE_BYTES (8 * 1024 * 1024)   // 8 MiB
#define BLOCK_SIZE 512                   // Tamaño fijo
#define NUM_BLOCKS (FS_SIZE_BYTES / BLOCK_SIZE)  // 16384 bloques

#define SUPERBLOCK_BLOCKS 5 // para el superbloque y bitmaps
#define INODE_TABLE_OFFSET (SUPERBLOCK_BLOCKS * BLOCK_SIZE)

#define NUM_INODES 1024
#define MAX_FILES_PER_DIR 64
#define FILENAME_LEN 32
#define DIRECT_BLOCKS 11

#define ROOT_DIR_INODE 0
#define FS_IMAGE "mi_fs.img"

#endif
