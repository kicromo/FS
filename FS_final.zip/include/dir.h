#ifndef DIR_H
#define DIR_H

#include <stdio.h>
#include "types.h"

int create_dir(const char* path);
int delete_dir(const char* path);
int rename_dir(const char* old_path, const char* new_path);
int list_dir(const char* path);

int find_entry_in_dir(FILE* fp, Inode* dir_inode, const char* name, DirEntry* out);
int add_entry_to_dir(FILE* fp, Inode* dir_inode, int dir_index, const char* name, int inode_index);
int remove_entry_from_dir(FILE* fp, Inode* dir_inode, int dir_index, const char* name);

int read_indirect_block(FILE* fp, int block_num, int* buffer);
int write_indirect_block(FILE* fp, int block_num, int* buffer);
#endif
