#ifndef SUPERBLOCK_H
#define SUPERBLOCK_H

#include <stdio.h>
#include "types.h"

void init_superblock(Superblock* sb);
int write_superblock(FILE* fp, Superblock* sb);
int read_superblock(FILE* fp, Superblock* sb);

int allocate_block(Superblock* sb);
void free_block(Superblock* sb, int block_num);
int is_block_free(Superblock* sb, int block_num);

int allocate_inode(Superblock* sb);
void free_inode(Superblock* sb, int inode_num);
int is_inode_free(Superblock* sb, int inode_num);

#endif
