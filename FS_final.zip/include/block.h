#ifndef BLOCK_H
#define BLOCK_H

#include <stdio.h>
#include <stddef.h>
#include "fs.h"

typedef struct {
    char data[BLOCK_SIZE];
} DataBlock;

void clear_block(FILE* fp, int block_num);
void write_block(FILE* fp, int block_num, const char* data, size_t len);
void read_block(FILE* fp, int block_num, char* buffer);

#endif
