#ifndef FILE_H
#define FILE_H

#include <stddef.h>
#include <stdio.h>
#include "types.h"

void mkfs(void);

int create_file(const char* path, const char* content);
int read_file(const char* path, char* buffer, size_t size);
int write_file(const char* path, const char* content);
int delete_file(const char* path);
int rename_file(const char* old_path, const char* new_path);
//int resolve_path(FILE* fp, const char* path, Inode* parent_inode, int* parent_inode_index, char* final_name);
int resolve_path_to_parent(FILE* fp, const char* path, Inode* parent_inode, int* parent_index, char* name);
int resolve_full_path(FILE* fp, const char* path, Inode* inode_out, int* inode_index_out);
int remove_entry_from_file_dir(FILE* fp, Inode* dir_inode, int dir_index, const char* name);
#endif
