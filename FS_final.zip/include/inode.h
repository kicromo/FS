#ifndef INODE_H
#define INODE_H

#include <stdio.h>
#include "types.h"

int write_inode(FILE* fp, int index, const Inode* inode);
int read_inode(FILE* fp, int index, Inode* inode);
void clear_inode(Inode* inode);

int allocate_data_block_for_inode(Inode* inode, int logical_block_idx, int* physical_block_num, FILE* fp, Superblock* sb, int inode_index);
int get_data_block_from_inode(const Inode* inode, int logical_block_idx, int* physical_block_num, FILE* fp);

#endif
