#ifndef TYPES_H
#define TYPES_H

#include <sys/types.h>
#include "fs.h"

// Entrada de un directorio
typedef struct {
    char name[FILENAME_LEN];
    int inode_index;
} DirEntry;

// Inodo
typedef struct {
    int used;                        // 1 si ocupado, 0 si libre
    int is_directory;               // 1 si es directorio
    int size;                       // en bytes
    int block_pointers[DIRECT_BLOCKS]; // bloques directos
    int indirect1;                  // bloque indirecto simple
    int indirect2;                  // bloque indirecto doble
    long atime;                     // tiempo de último acceso
    long mtime;                     // tiempo de última modificación
    long ctime;                     // tiempo de cambio
    mode_t mode;                    // permisos y tipo de archivo 
} Inode;

// Superbloque
typedef struct {
    int magic_number;
    int num_blocks;
    int block_size;
    int num_inodes;
    int root_inode_index;
    
    int free_inode_bitmap[NUM_INODES / 32];  // 1024 / 32 = 32 ints = 128 B
    int free_block_bitmap[NUM_BLOCKS / 32];  // 16384 / 32 = 512 ints = 2 KiB
} Superblock;

#endif
