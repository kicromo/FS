#define FUSE_USE_VERSION 26

#include <fuse.h>
#include "fs_fuselib.h"

static struct fuse_operations mi_oper = {
    .getattr = fs_getattr_fuse,
    .readdir = fs_readdir_fuse,
    .open    = fs_open_fuse,
    .read    = fs_read_fuse,
    .create  = fs_create_fuse,
    .write   = fs_write_fuse,
    .unlink  = fs_unlink_fuse,
    .rename  = fs_rename_fuse,
    .mkdir   = fs_mkdir_fuse,
    .truncate = fs_truncate_fuse,
    .rmdir    = fs_rmdir_fuse,
    .utimens = fs_utimens_fuse,
    .fsync   = fs_fsync_fuse,
    .chmod   = fs_chmod_fuse,
};

int main(int argc, char *argv[]) {
    return fuse_main(argc, argv, &mi_oper, NULL);
}
