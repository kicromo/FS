#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "fs_fuselib.h"
#include "fs.h"
#include "file.h"
#include "dir.h"
#include "inode.h"
#include "block.h"
#include "superblock.h"
#include "types.h"

// fs_fuselib.c
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#define FS_IMAGE_PATH "mi_fs.img"

int fs_getattr_fuse(const char* path, struct stat* stbuf) {
    memset(stbuf, 0, sizeof(struct stat));

    // Manejar caso especial del directorio raíz
    if (strcmp(path, "/") == 0) {
        stbuf->st_mode = S_IFDIR | 0755;
        stbuf->st_nlink = 2;
        stbuf->st_size = 512;
        return 0;
    }

    FILE* fp = fopen(FS_IMAGE_PATH, "rb");
    if (!fp) return -EIO;

    Inode inode;
    int inode_index;
    if (resolve_full_path(fp, path, &inode, &inode_index) != 0) {
        fclose(fp);
        return -ENOENT;
    }

    if (inode.is_directory) {
        stbuf->st_mode = S_IFDIR | inode.mode;
        stbuf->st_nlink = 2;
    } else {
        stbuf->st_mode = S_IFREG | inode.mode;
        stbuf->st_nlink = 1;
        stbuf->st_size = inode.size;
    }
    stbuf->st_atime = inode.atime;
    stbuf->st_mtime = inode.mtime;
    stbuf->st_ctime = inode.ctime;

    fclose(fp);
    return 0;
}

int fs_readdir_fuse(const char* path, void* buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info* fi) {
    (void) offset; (void) fi;

    FILE* fp = fopen(FS_IMAGE_PATH, "rb");
    if (!fp) return -EIO;

    Inode dir_inode;
    int inode_index;

    if (strcmp(path, "/") == 0) {
        // Acceder al inodo raíz directamente
        inode_index = ROOT_DIR_INODE;
        if (read_inode(fp, inode_index, &dir_inode) != 0) {
            fclose(fp);
            return -EIO;
        }
    } else {
        // Resto de rutas: usar resolve
        if (resolve_full_path(fp, path, &dir_inode, &inode_index) != 0 || !dir_inode.is_directory) {
            fclose(fp);
            return -ENOENT;
        }
    }

    filler(buf, ".", NULL, 0);
    filler(buf, "..", NULL, 0);

    DirEntry entry;
    int num_entries = dir_inode.size / sizeof(DirEntry);
    for (int i = 0; i < num_entries; i++) {
        long offset = dir_inode.block_pointers[0] * BLOCK_SIZE + i * sizeof(DirEntry);
        fseek(fp, offset, SEEK_SET);
        fread(&entry, sizeof(DirEntry), 1, fp);
        filler(buf, entry.name, NULL, 0);
    }

    fclose(fp);
    return 0;
}

int fs_open_fuse(const char* path, struct fuse_file_info* fi) {
    FILE* fp = fopen(FS_IMAGE_PATH, "rb");
    if (!fp) return -EIO;

    Inode inode;
    int inode_index;
    if (resolve_full_path(fp, path, &inode, &inode_index) != 0) {
        fclose(fp);
        return -ENOENT;
    }

    fclose(fp);
    return 0;
}

int fs_read_fuse(const char* path, char* buf, size_t size, off_t offset, struct fuse_file_info* fi) {
    (void) fi;
    FILE* fp = fopen(FS_IMAGE_PATH, "rb");
    if (!fp) return -EIO;

    char* temp = calloc(1, size + offset + 1);
    if (!temp) {
        fclose(fp);
        return -ENOMEM;
    }

    if (read_file(path, temp, size + offset) != 0) {
        free(temp);
        fclose(fp);
        return -ENOENT;
    }

    size_t len = strlen(temp);
    if (offset >= len) {
        free(temp);
        fclose(fp);
        return 0;
    }

    if (offset + size > len)
        size = len - offset;

    memcpy(buf, temp + offset, size);
    free(temp);
    fclose(fp);
    return size;
}

int fs_create_fuse(const char* path, mode_t mode, struct fuse_file_info* fi) {
    (void) mode; (void) fi;
    if (create_file(path, "") != 0) return -EIO;
    return 0;
}

int fs_write_fuse(const char* path, const char* buf, size_t size, off_t offset, struct fuse_file_info* fi) {
    (void) offset; (void) fi;
    char* content = calloc(1, size + 1);
    strncpy(content, buf, size);
    int res = write_file(path, content);
    free(content);
    return (res == 0) ? size : -EIO;
}

int fs_unlink_fuse(const char* path) {
    return (delete_file(path) == 0) ? 0 : -EIO;
}

int fs_rename_fuse(const char* from, const char* to) {
    return (rename_file(from, to) == 0) ? 0 : -EIO;
}

int fs_mkdir_fuse(const char* path, mode_t mode) {
    (void)mode;
    return (create_dir(path) == 0) ? 0 : -EIO;
}

int fs_truncate_fuse(const char* path, off_t size) {
    (void)path;
    (void)size;
    // Si no quieres truncar, simplemente devuelve éxito sin hacer nada
    return 0;
}

int fs_rmdir_fuse(const char* path) {
    return (delete_dir(path) == 0) ? 0 : -EIO;
}


int fs_utimens_fuse(const char* path, const struct timespec tv[2]) {
    FILE* fp = fopen(FS_IMAGE_PATH, "r+b");
    if (!fp) return -EIO;
    Inode inode;
    int inode_index;
    if (resolve_full_path(fp, path, &inode, &inode_index) != 0) {
        fclose(fp);
        return -ENOENT;
    }
    if (tv) {
        inode.atime = tv[0].tv_sec;
        inode.mtime = tv[1].tv_sec;
    }
    inode.ctime = time(NULL);
    write_inode(fp, inode_index, &inode);
    fclose(fp);
    return 0;
}

int fs_fsync_fuse(const char* path, int isdatasync, struct fuse_file_info* fi) {
    (void)path;
    (void)isdatasync;
    (void)fi;
    return 0;
}

int fs_chmod_fuse(const char* path, mode_t mode) {
    FILE* fp = fopen(FS_IMAGE_PATH, "r+b");
    if (!fp) return -EIO;
    Inode inode;
    int inode_index;
    if (resolve_full_path(fp, path, &inode, &inode_index) != 0) {
        fclose(fp);
        return -ENOENT;
    }
    inode.mode = mode;
    inode.ctime = time(NULL);
    write_inode(fp, inode_index, &inode);
    fclose(fp);
    return 0;
}