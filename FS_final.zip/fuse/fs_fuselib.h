#ifndef FS_FUSELIB_H
#define FS_FUSELIB_H

#include <fuse.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

/**
 * Wrappers para mapear las funciones de tu sistema de ficheros a FUSE
 */

int fs_getattr_fuse(const char* path, struct stat* stbuf);
int fs_readdir_fuse(const char* path, void* buf, fuse_fill_dir_t filler, off_t offset, struct fuse_file_info* fi);
int fs_open_fuse(const char* path, struct fuse_file_info* fi);
int fs_read_fuse(const char* path, char* buf, size_t size, off_t offset, struct fuse_file_info* fi);
int fs_create_fuse(const char* path, mode_t mode, struct fuse_file_info* fi);
int fs_write_fuse(const char* path, const char* buf, size_t size, off_t offset, struct fuse_file_info* fi);
int fs_unlink_fuse(const char* path);
int fs_rename_fuse(const char* from, const char* to);
int fs_mkdir_fuse(const char* path, mode_t mode);
int fs_truncate_fuse(const char* path, off_t size);
int fs_rmdir_fuse(const char* path);
int fs_utimens_fuse(const char* path, const struct timespec tv[2]);
int fs_fsync_fuse(const char* path, int isdatasync, struct fuse_file_info* fi);
int fs_chmod_fuse(const char* path, mode_t mode);
#endif // FS_FUSELIB_H
