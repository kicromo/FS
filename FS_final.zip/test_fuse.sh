#!/bin/bash
# Script de pruebas legible para sistema de ficheros FUSE
# Autores: Ilie y Diego - GrupoK
MOUNT=punto_montaje
set -e

echo "[1] Limpiando entorno de pruebas..."
rm -rf "$MOUNT/testdir" "$MOUNT/testfile.txt" "$MOUNT/testdir2" "$MOUNT/testdir_renamed" "$MOUNT/testfile_renamed.txt" 2>/dev/null || true

echo "[2] Creando directorio testdir..."
mkdir "$MOUNT/testdir"
ls -l "$MOUNT"

echo "[3] Creando archivo testfile.txt y escribiendo contenido..."
echo "Hola FUSE" > "$MOUNT/testfile.txt"
ls -l "$MOUNT"

echo "[4] Leyendo contenido de testfile.txt..."
cat "$MOUNT/testfile.txt"

echo "[5] Renombrando archivo testfile.txt a testfile_renamed.txt..."
mv "$MOUNT/testfile.txt" "$MOUNT/testfile_renamed.txt"
ls -l "$MOUNT"

echo "[6] Renombrando directorio testdir a testdir_renamed..."
mv "$MOUNT/testdir" "$MOUNT/testdir_renamed"
ls -l "$MOUNT"

echo "[7] Creando subdirectorios y archivos dentro de testdir_renamed..."
mkdir "$MOUNT/testdir_renamed/subdir"
echo "Subarchivo" > "$MOUNT/testdir_renamed/subfile.txt"
ls -l "$MOUNT/testdir_renamed"

echo "[8] Listando contenido de testdir_renamed/subdir (debe estar vacío)..."
ls -l "$MOUNT/testdir_renamed/subdir"

echo "[9] Borrando archivo testfile_renamed.txt..."
rm "$MOUNT/testfile_renamed.txt"
ls -l "$MOUNT"

echo "[10] Borrando archivo y subdirectorio dentro de testdir_renamed..."
rm "$MOUNT/testdir_renamed/subfile.txt"
rmdir "$MOUNT/testdir_renamed/subdir"
ls -l "$MOUNT/testdir_renamed"

echo "[11] Borrando directorio testdir_renamed..."
rmdir "$MOUNT/testdir_renamed"
ls -l "$MOUNT"

echo "[12] Prueba de error: intentar borrar directorio no vacío..."
mkdir "$MOUNT/testdir2"
echo "algo" > "$MOUNT/testdir2/file.txt"
if rmdir "$MOUNT/testdir2" 2>/dev/null; then
  echo "ERROR: Se pudo borrar un directorio no vacío (esto no debería pasar)"
else
  echo "Correcto: No se puede borrar un directorio no vacío"
fi
rm "$MOUNT/testdir2/file.txt"
rmdir "$MOUNT/testdir2"

echo "[13] Pruebas de timestamps (atime, mtime, ctime) sobre testfile_time.txt..."
TESTFILE="$MOUNT/testfile_time.txt"
echo "inicial" > "$TESTFILE"
stat --format '%X %Y %Z' "$TESTFILE" > /tmp/times_before
ATIME1=$(cut -d' ' -f1 /tmp/times_before)
MTIME1=$(cut -d' ' -f2 /tmp/times_before)
CTIME1=$(cut -d' ' -f3 /tmp/times_before)
echo "Tiempos iniciales: atime=$ATIME1 mtime=$MTIME1 ctime=$CTIME1"
sleep 2
cat "$TESTFILE" > /dev/null
stat --format '%X %Y %Z' "$TESTFILE" > /tmp/times_after_read
ATIME2=$(cut -d' ' -f1 /tmp/times_after_read)
MTIME2=$(cut -d' ' -f2 /tmp/times_after_read)
CTIME2=$(cut -d' ' -f3 /tmp/times_after_read)
echo "Tras lectura: atime=$ATIME2 mtime=$MTIME2 ctime=$CTIME2"
sleep 2
echo "modificado" > "$TESTFILE"
stat --format '%X %Y %Z' "$TESTFILE" > /tmp/times_after_write
ATIME3=$(cut -d' ' -f1 /tmp/times_after_write)
MTIME3=$(cut -d' ' -f2 /tmp/times_after_write)
CTIME3=$(cut -d' ' -f3 /tmp/times_after_write)
echo "Tras escritura: atime=$ATIME3 mtime=$MTIME3 ctime=$CTIME3"
sleep 2
mv "$TESTFILE" "$MOUNT/testfile_time_renamed.txt"
stat --format '%X %Y %Z' "$MOUNT/testfile_time_renamed.txt" > /tmp/times_after_rename
ATIME4=$(cut -d' ' -f1 /tmp/times_after_rename)
MTIME4=$(cut -d' ' -f2 /tmp/times_after_rename)
CTIME4=$(cut -d' ' -f3 /tmp/times_after_rename)
echo "Tras renombrado: atime=$ATIME4 mtime=$MTIME4 ctime=$CTIME4"
rm -f "$MOUNT/testfile_time_renamed.txt" /tmp/times_before /tmp/times_after_read /tmp/times_after_write /tmp/times_after_rename

echo "[14] Pruebas de chmod (cambio de permisos) sobre testfile_chmod.txt y testdir_chmod..."
TESTFILE_CHMOD="$MOUNT/testfile_chmod.txt"
TESTDIR_CHMOD="$MOUNT/testdir_chmod"
echo "contenido" > "$TESTFILE_CHMOD"
mkdir "$TESTDIR_CHMOD"
chmod 400 "$TESTFILE_CHMOD"
PERM_FILE=$(stat -c '%a' "$TESTFILE_CHMOD")
echo "Permisos tras chmod 400: $PERM_FILE (esperado: 400)"
chmod 600 "$TESTFILE_CHMOD"
PERM_FILE=$(stat -c '%a' "$TESTFILE_CHMOD")
echo "Permisos tras chmod 600: $PERM_FILE (esperado: 600)"
chmod 111 "$TESTDIR_CHMOD"
PERM_DIR=$(stat -c '%a' "$TESTDIR_CHMOD")
echo "Permisos dir tras chmod 111: $PERM_DIR (esperado: 111)"
chmod 755 "$TESTDIR_CHMOD"
chmod 644 "$TESTFILE_CHMOD"
rm -f "$TESTFILE_CHMOD"
rmdir "$TESTDIR_CHMOD"


echo "*****"
echo "Fin de pruebas."
echo "*****"
